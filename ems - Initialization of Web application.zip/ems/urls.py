"""ems URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from ems_central.views import onboarding_employee,cur_employee,home,old_employee,outsource_staff,stats

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',home,name='home'),
    path('oe/<str:type>/<str:id>',onboarding_employee,name='oe'),
    path('ce/<str:type>/<str:id>',cur_employee,name='ce'),
path('pe/<str:type>/<str:id>',old_employee,name='pe'),
path('ee/<str:type>/<str:id>',outsource_staff,name='ee'),
    path('stats/<str:type>',stats,name='stats')

    # path('edit/<str:type>/<str:id>',edit_record,name='edit')
    # path('oe/',update_oe_employee,name='oe_update')
]
