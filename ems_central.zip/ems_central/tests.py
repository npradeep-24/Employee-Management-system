# l=[7,2,1,290,2,3,4,0,3,78,93]
#
# def sort(sq):
#     new_l=sq.copy()
#     for x in range(len(sq)):
#         for y in range(x+1,len(sq)):
#             if new_l[x]<new_l[y]:
#                 new_l[x],new_l[y]=new_l[y],new_l[x]
#
#     return new_l
#
#
# print(sort(sq=l))
# print(l)

# a=[12,3,4,3,34,7]
#
# new_l=[]
# sc_l=a.copy()
# for x in range(len(a)):
#     new_l.append(x)
#
#
# print(new_l[0] is a[0])
# print(sc_l[0] is a[0])



# import sqlite3
#
#
#
#
# con=sqlite3.connect('db.sqlite3')
# # query="select * from ems_central_current_employees"
# query ="SELECT * from ems_central_current_employees;"
# cur=con.cursor()
# cur.execute(query)
# print(cur.fetchall())













