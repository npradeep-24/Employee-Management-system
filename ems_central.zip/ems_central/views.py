from django.shortcuts import render,HttpResponse,redirect,HttpResponseRedirect,reverse
from .forms import onboarding_employees_form,current_employees_form,old_employees_form,outsource_employees_form
from .models import onboarding_employees,current_employees,old_employees,outsource_employees,employee_gender
import sqlite3
# Create your views here.

def home(request):
    return render(request,'home.html')

def onboarding_employee(request,type='none',id='none'):
    if request.method=='POST':
        if 'add' in request.POST:
            form=onboarding_employees_form(request.POST)
            if form.is_valid():
                form.save()
                return HttpResponseRedirect(reverse('oe',kwargs={'type':'njd','id':'cskj'}))
            else:
                return render(request,'oe_form.html',{'form':form})


        elif 'del' in request.POST:
            if onboarding_employees.objects.filter(govt_id__exact=request.POST['govt_id']):
                onboarding_employees.objects.get(govt_id__exact=request.POST['govt_id']).delete()
                return HttpResponseRedirect(reverse('oe',kwargs={'type':'njd','id':'cskj'}))
        elif 'update' in request.POST:
            if onboarding_employees.objects.filter(govt_id__exact=request.POST['govt_id']):
                obj=onboarding_employees.objects.get(govt_id__exact=request.POST['govt_id'])
                form=onboarding_employees_form(request.POST,instance=obj)
                if form.is_valid():
                    form.save()
                    return HttpResponseRedirect(reverse('oe', kwargs={'type': 'njd', 'id': 'cskj'}))
                else:
                    return render(request,'oe_form.html',{'form':form})

        else:
            return HttpResponse('')



    else:
        if type=='add':
            form=onboarding_employees_form()
            return render(request,'oe_form.html',{'form':form})
        elif type=='edit':
            obj=onboarding_employees.objects.get(govt_id__exact=id)
            form=onboarding_employees_form(instance=obj)
            return render(request, 'oe_form.html', {'form': form})

        else:
            records=onboarding_employees.objects.all()
            return render(request,'oe_records.html',{'records':records})

    #     if 'del' in request.POST:
    #         id=request.POST['govt_id']
    #         onboarding_employees.objects.get(govt_id__exact=id).delete()
    #         return redirect('oe')
    #     else:
    #         form = onboarding_employees_form(request.POST)
    #         if form.is_valid():
    #             form.save()
    #             return HttpResponse('done')
    #         else:
    #             return render(request, 'index.html', {'context': form})
    # else:
    #     records = onboarding_employees.objects.all()
    #     return render(request,'records.html',{'records':records,'code':'oe'})


# def edit_record(request,type,id):
#     if type=='oe':
#         obj=onboarding_employees.objects.get(govt_id__exact=id)
#         form=onboarding_employees_form(instance=obj)
#         return render(request,'form.html',{'form':form})


def cur_employee(request,type='none',id='none'):
    if request.method=='POST':
        if 'add' in request.POST:
            form=current_employees_form(request.POST)
            if form.is_valid():
                form.save()
                return HttpResponseRedirect(reverse('ce',kwargs={'type':'njd','id':'cskj'}))
            else:
                return render(request,'ce_form.html',{'form':form})



        elif 'del' in request.POST:
            if current_employees.objects.filter(emp_id__exact=request.POST['emp_id']):
                current_employees.objects.get(emp_id__exact=request.POST['emp_id']).delete()
                return HttpResponseRedirect(reverse('ce',kwargs={'type':'njd','id':'cskj'}))
        elif 'update' in request.POST:
            if current_employees.objects.filter(emp_id__exact=request.POST['emp_id']):
                obj=current_employees.objects.get(emp_id__exact=request.POST['emp_id'])
                form=current_employees_form(request.POST,instance=obj)
                if form.is_valid():
                    form.save()
                    return HttpResponseRedirect(reverse('ce', kwargs={'type': 'njd', 'id': 'cskj'}))
                else:
                    return render(request,'ce_form.html',{'form':form})
        else:
            return redirect('home')


    else:
        if type=='add':
            form=current_employees_form()
            return render(request,'ce_form.html',{'form':form})
        elif type=='edit':
            obj=current_employees.objects.get(emp_id__exact=id)
            form=current_employees_form(instance=obj)
            return render(request, 'ce_form.html', {'form': form})

        else:
            records=current_employees.objects.all()
            return render(request,'ce_records.html',{'records':records})


def old_employee(request,type='none',id='none'):
    if request.method=='POST':
        if 'add' in request.POST:
            form=old_employees_form(request.POST)
            if form.is_valid():
                form.save()
                return HttpResponseRedirect(reverse('pe',kwargs={'type':'njd','id':'cskj'}))
            else:
                return render(request,'pe_form.html',{'form':form})



        elif 'del' in request.POST:
            if old_employees.objects.filter(emp_id__exact=request.POST['emp_id']):
                old_employees.objects.get(emp_id__exact=request.POST['emp_id']).delete()
                return HttpResponseRedirect(reverse('pe',kwargs={'type':'njd','id':'cskj'}))
        elif 'update' in request.POST:
            if old_employees.objects.filter(emp_id__exact=request.POST['emp_id']):
                obj=old_employees.objects.get(emp_id__exact=request.POST['emp_id'])
                form=old_employees_form(request.POST,instance=obj)
                if form.is_valid():
                    form.save()
                    return HttpResponseRedirect(reverse('pe', kwargs={'type': 'njd', 'id': 'cskj'}))
                else:
                    return render(request,'pe_form.html',{'form':form})
        else:
            return redirect('home')



    else:
        if type=='add':
            form=old_employees_form()
            return render(request,'pe_form.html',{'form':form})
        elif type=='edit':
            obj=old_employees.objects.get(emp_id__exact=id)
            form=old_employees_form(instance=obj)
            return render(request, 'pe_form.html', {'form': form})

        else:
            records=old_employees.objects.all()
            return render(request,'pe_records.html',{'records':records})



def outsource_staff(request,type='none',id='none'):
    if request.method=='POST':
        if 'add' in request.POST:
            form=outsource_employees_form(request.POST)
            if form.is_valid():
                form.save()
                return HttpResponseRedirect(reverse('ee',kwargs={'type':'njd','id':'cskj'}))
            else:
                return render(request,'ee_form.html',{'form':form})



        elif 'del' in request.POST:
            if outsource_employees.objects.filter(emp_id__exact=request.POST['emp_id']):
                outsource_employees.objects.get(emp_id__exact=request.POST['emp_id']).delete()
                return HttpResponseRedirect(reverse('ee',kwargs={'type':'njd','id':'cskj'}))
        elif 'update' in request.POST:
            if outsource_employees.objects.filter(emp_id__exact=request.POST['emp_id']):
                obj=outsource_employees.objects.get(emp_id__exact=request.POST['emp_id'])
                form=outsource_employees_form(request.POST,instance=obj)
                if form.is_valid():
                    form.save()
                    return HttpResponseRedirect(reverse('ee', kwargs={'type': 'njd', 'id': 'cskj'}))
                else:
                    return render(request,'ee_form.html',{'form':form})
        else:
            return redirect('home')



    else:
        if type=='add':
            form=outsource_employees_form()
            return render(request,'ee_form.html',{'form':form})
        elif type=='edit':
            obj=outsource_employees.objects.get(emp_id__exact=id)
            form=outsource_employees_form(instance=obj)
            return render(request, 'ee_form.html', {'form': form})

        else:
            records=outsource_employees.objects.all()
            return render(request,'ee_records.html',{'records':records})





def stats(request,type):
    if type=='te':
        r1=current_employees.objects.all().values('emp_id','name','designation')
        r2=outsource_employees.objects.all().values('emp_id','name','designation')
        records=r1.union(r2)
        return render(request,'stats.html',{'records':records,'ctg':'Total Working Employees'})

    elif type=='mr':
        r1=current_employees.objects.filter(designation__role_id__contains='mng').values('emp_id','name','designation')
        r2=outsource_employees.objects.filter(designation__role_id__contains='mng').values('emp_id','name','designation')
        records=r1.union(r2)
        return render(request,'stats.html',{'records':records,'ctg':'Managers'})

    else:
        # r1=current_employees.objects.filter(gender_code__gender_code__exact='male').values('emp_id','name','designation')
        # r2=outsource_employees.objects.filter(gender_code__gender_code__exact='male').values('emp_id','name','designation')
        # records=r1.union(r2)
        query = "select ems_central_current_employees.emp_id,ems_central_current_employees.name,ems_central_outsource_employees.emp_id,ems_central_outsource_employees.name from ems_central_current_employees inner JOIN ems_central_outsource_employees ON ems_central_outsource_employees.name==ems_central_current_employees.name"
        con = sqlite3.connect('db.sqlite3')
        curs = con.cursor()
        curs.execute(query)
        records = curs.fetchall()
        return render(request,'stats.html',{'rec':records,'ctg':'Male Staff'})




