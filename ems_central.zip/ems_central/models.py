from django.db import models


# Create your models here.

class offices(models.Model):
    office_id=models.CharField(max_length=50,primary_key=True)
    city=models.CharField(max_length=100)
    address=models.CharField(max_length=200)

class employee_gender(models.Model):
    gender_code=models.CharField(max_length=20,primary_key=True)
    def __str__(self):
        return self.gender_code

class designations(models.Model):
    role_id=models.CharField(max_length=100,primary_key=True)
    role_name=models.CharField(max_length=100)
    salary=models.IntegerField()

    def __str__(self):
        return self.role_name



#3nf table
class onboarding_employees(models.Model):
    govt_id = models.CharField(max_length=50, primary_key=True)
    name=models.CharField(max_length=100)
    email=models.EmailField(max_length=100)
    dob=models.DateField()
    gender_code=models.ForeignKey('employee_gender',on_delete=models.RESTRICT)







#3nf table
class current_employees(models.Model):

    def emp_id_gen(self):
        a=self.name[:2]+self.designation.role_id+self.pk
        return a
    emp_id=models.CharField(primary_key=True,max_length=100)
    name=models.CharField(max_length=100)
    dob = models.DateField()
    designation=models.ForeignKey('designations',on_delete=models.RESTRICT)
    gender_code = models.ForeignKey('employee_gender',on_delete=models.RESTRICT)




#3nf table
class old_employees(models.Model):
    emp_id = models.CharField(max_length=100, primary_key=True)
    name = models.CharField(max_length=100)
    dob = models.DateField()
    designation = models.ForeignKey('designations',on_delete=models.RESTRICT)
    gender_code = models.ForeignKey('employee_gender',on_delete=models.RESTRICT)



#3nf table
class outsource_employees(models.Model):
    emp_id = models.CharField(max_length=100, primary_key=True)
    name = models.CharField(max_length=100)
    source_company=models.ForeignKey('outsorce_companies',on_delete=models.RESTRICT)
    designation = models.ForeignKey('designations',on_delete=models.RESTRICT)
    gender_code = models.ForeignKey('employee_gender',on_delete=models.RESTRICT)

class outsorce_companies(models.Model):
    company_id=models.CharField(max_length=50,primary_key=True)
    company_name=models.CharField(max_length=100)

    def __str__(self):
        return self.company_name









