from django.contrib import admin
from .models import employee_gender,onboarding_employees,designations,offices,outsorce_companies

# Register your models here.

admin.site.register(employee_gender)
admin.site.register(onboarding_employees)
admin.site.register(designations)
admin.site.register(offices)
admin.site.register(outsorce_companies)
