from django import forms
from .models import employee_gender,onboarding_employees,current_employees,old_employees,outsource_employees

class onboarding_employees_form(forms.ModelForm):
    class Meta:
        model=onboarding_employees
        fields=('govt_id','name','email','dob','gender_code')
        widgets={
            'govt_id':forms.TextInput(attrs={"class":"form-control"}),
            'name':forms.TextInput(attrs={'class':'form-control'}),
            'email':forms.TextInput(attrs={'class':'form-control'}),
            'dob':forms.DateInput(attrs={'class': 'form-control', 'placeholder': 'YYYY-MM-DD'}),
            'gender_code':forms.Select(attrs={'class': 'form-control'})
        }


class current_employees_form(forms.ModelForm):
    class Meta:
        model=current_employees
        fields=('emp_id','name','dob','designation','gender_code')
        widgets={
            'emp_id':forms.TextInput(attrs={'class':'form-control'}),
            'name':forms.TextInput(attrs={'class':'form-control'}),
            'dob':forms.DateInput(attrs={'class': 'form-control', 'placeholder': 'YYYY-MM-DD'}),
            'designation': forms.Select(attrs={'class': 'form-control'}),
            'gender_code':forms.Select(attrs={'class': 'form-control'})
        }


class old_employees_form(forms.ModelForm):
    class Meta:
        model=old_employees
        fields=('emp_id','name','dob','designation','gender_code')
        widgets={
            'emp_id':forms.TextInput(attrs={'class':'form-control'}),
            'name':forms.TextInput(attrs={'class':'form-control'}),
            'dob':forms.DateInput(attrs={'class': 'form-control', 'placeholder': 'YYYY-MM-DD'}),
            'designation': forms.Select(attrs={'class': 'form-control'}),
            'gender_code':forms.Select(attrs={'class': 'form-control'})
        }


class outsource_employees_form(forms.ModelForm):
    class Meta:
        model=outsource_employees
        fields=('emp_id','name','source_company','designation','gender_code')
        widgets={
            'emp_id':forms.TextInput(attrs={'class':'form-control'}),
            'name':forms.TextInput(attrs={'class':'form-control'}),
            'source_company': forms.Select(attrs={'class': 'form-control'}),
            'designation': forms.Select(attrs={'class': 'form-control'}),
            'gender_code':forms.Select(attrs={'class': 'form-control'})
        }






# class current_employee_form(forms.ModelForm):
#     class Meta:
#         model=employee_gender

# govt_id = forms.CharField(required=True,label='govt_id',max_length=100,widget=forms.TextInput(attrs={'class':'form-control'}))
    # name = forms.CharField(required=True,max_length=100,label='name',widget=forms.TextInput(attrs={'class':'form-control'}))
    # email = forms.EmailField(required=True,max_length=100,label='email',widget=forms.TextInput(attrs={'class':'form-control'}))
    # choice=(('','select gender'),('m','male'),('f','female'),('tg','trans gender'))
    # dob=forms.DateField(required=True,widget=forms.DateInput(attrs={'class': 'form-control', 'placeholder': 'DD/MM/YYYY'}))
    # gender_code = forms.ModelChoiceField(empty_label='select gender',queryset=employee_gender.objects.all(),required=True,widget=forms.Select(attrs={'class': 'form-control'}))
